# Greed

A [customizable](/config/template_config.toml), [multilanguage](/strings) Telegram shop bot with [Telegram Payments support](https://core.telegram.org/bots/payments)!  

\[ [**Documentation**](https://github.com/Steffo99/greed/wiki) | [Support](https://github.com/Steffo99/greed/issues/new/choose) \]

![](https://i.imgur.com/FdT2tRV.png)

![](https://i.imgur.com/rDYWdUB.png)

![](https://i.imgur.com/9plMzO6.png)
